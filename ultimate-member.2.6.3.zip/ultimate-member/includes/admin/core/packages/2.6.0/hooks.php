<?php if ( ! defined( 'ABSPATH' ) ) exit;

return array(
	'social_fields260' => 'social_fields260',
);
